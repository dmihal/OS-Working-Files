Dylan Kirby
David Mihal
Project 1

This project has 3 programs: runCommand, shell, and shell2

Type 'make' to compile all 3 programs

runCommand takes a program and arguments a

shell2 uses an array of "jobs" structs to maintain a list of running processes.

